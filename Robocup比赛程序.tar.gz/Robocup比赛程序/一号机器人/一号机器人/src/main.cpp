/*
 * main.cpp
 *
 *  Created on: 2014年6月23日
 *      Author: xuf
 */
#include "global.h"
int main(void)
{
#ifdef GONG_KONG
	cout<<"run on gong_kong"<<endl;
#else
	cout<<"运行于电脑"<<endl;
#endif

#ifdef GONG_KONG
	cout<<"initial ttyS0"<<endl;
	fd = portInit("/dev/ttyS0");
#else
	cout<<"初始化ttyUSB0"<<endl;
	fd = portInit("/dev/ttyUSB0");
#endif
//	updateOneStep(Vector3D(0, 0, 0));

//cout<<"head angle="<<calc_angle()<<endl;
//	serial_all();
//	sendfile("right_catch2.txt");
//	delay_sec(0.2);

//	robot_info.yaw_start=-70;//初始电子罗盘0角与场地0`角的差值  南球门（对着11出口）
		//robot_info.yaw_start=162;//北球门
//	euler_init();
	Image_Init();
	pre_reset();
//	udp_broadcast_client_init( 3838);
//	server_sock_init(&client_sock, 8888, "192.168.1.100");

update_still();
delay_sec(20);


/*	pthread_t network_t;
	if(pthread_create(&network_t, NULL, network_pthread, NULL) != 0)
	cout<<"body_pthread failed"<<endl;
	cout<<" body_pthread succeeded"<<endl;*/

	pthread_t img_t;
	if(pthread_create(&img_t, NULL, image_pthread, NULL) != 0)
		cout<<"image_pthread failed"<<endl;
	cout<<" image_pthread succeeded"<<endl;

	pthread_t head_t;
	if(pthread_create(&head_t, NULL, head_pthread, NULL) != 0)
		cout<<"head_pthread failed"<<endl;
	cout<<" head_pthread succeeded"<<endl;

	pthread_t body_t;
	if(pthread_create(&body_t, NULL, body_pthread, NULL) != 0)
	cout<<"body_pthread failed"<<endl;
	cout<<" body_pthread succeeded"<<endl;

	pthread_t serial_t;
	if(pthread_create(&serial_t, NULL, serial_pthread, NULL) != 0)
	cout<<"serial_pthread failed"<<endl;
	cout<<" serial_pthread succeeded"<<endl;


	void *pthread_result;
	pthread_join(img_t, &pthread_result);
	pthread_join(head_t, &pthread_result);
	pthread_join(body_t,&pthread_result);
	pthread_join(serial_t,&pthread_result);
//	pthread_join(network_t,&pthread_result);
	cout<<(void *)pthread_result<<endl;




	return 0;
}





