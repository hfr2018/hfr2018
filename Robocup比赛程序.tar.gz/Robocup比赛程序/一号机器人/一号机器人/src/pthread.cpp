/*
 * pthread.cpp
 *
 *  Created on: 2014年10月2日
 *      Author: xuf
 */

#include "global.h"





//检查pid追球状态跳出条件
bool chase_ball_should_break(void)
{
	if(robot_info.fall_info != 0){
		robot_info.robot_state = stand_up;
		return true;
	}
	if(!robot_info.ball_find){
		robot_info.robot_state = search_ball;
		return true;
	}
	if(robot_info.catch_ball_flag != 0){
			robot_info.robot_state = catch_ball;
			return true;
		}

	return false;
}

bool catch_ball_should_break(void)
{
	if(robot_info.fall_info == 0){
		robot_info.robot_state = search_ball;
		return true;
	}
	return false;
}

//pid追球
void pid_chase_ball(void)
{
	double angle_change[2];
	int start_count = 0;
//	int get_points_count = 0;
	double t1 = get_time(),t2;
	while(!chase_ball_should_break()){
//	while(!robot_info.ball_lost){
		if(start_count < 2){
			start_count++;
			 angle_change[0] = 25 * (robot_info.ball_info.x - 160) / 160 * 0.3;
			 angle_change[1] = 21 * (robot_info.ball_info.y - 120) / 120 * 0.2;
			 move_head(head_angle[0] - angle_change[0], head_angle[1] - angle_change[1]);
			 delay_sec(0.1);
			if(robot_info.ball_find){
				delay_sec(0.2);
			}
			else{
				continue;
			}
		}
		else{
			angle_change[0] = pid_calc_lower(&pid_lower);
			angle_change[1] = pid_calc_upper(&pid_upper);
//			cout<<"angle change = "<<angle_change[0]<<" "<<angle_change[1]<<endl;
			move_head(head_angle[0] - angle_change[0], head_angle[1] - angle_change[1]);
			delay_sec(pid_upper.t);
/*			get_points_count++;
			if(get_points_count == 3)
			{
				robot_info.start_take_pos_flag = true;
			}*/
		}
//		if(robot_info.start_take_pos_flag == true)
//		{
			t2 = get_time();
			if((t2 - t1)>pre_par.interval )
			{
				cout<<"interval = "<<t2-t1<<endl;
				update_points(t2 - t1);
				t1 = t2;
			}
//		}
		if(robot_info.ball_dis4robot<=80)
		{
			cout<<"ball distance = "<<robot_info.ball_dis4robot<<endl;
			double v = get_pre_res();
			cout<<"speed = "<<v<<endl;
			if((v > 50)&&(v<100))
			{
				if(head_angle[0]<0) 				robot_info.catch_ball_flag =1;
				else	robot_info.catch_ball_flag =2;
			}

		}
	}
//	robot_info.start_take_pos_flag = false;

	if(!robot_info.ball_find){
		int lost_count = 0;
		while(!robot_info.ball_find && lost_count < 2){
			lost_count++;
			angle_change[0] = pid_calc_lower(&pid_lower) * 1;
			angle_change[1] = pid_calc_upper(&pid_upper) * 1;
			move_head(head_angle[0] - angle_change[0], head_angle[1] - angle_change[1]);
			delay_sec(pid_upper.t);
		}
		pid_reset();
//		pre_reset();
	}
}

//锯齿波函数
double saw(double t, const double T)
{
	if(t < T/4){
		return t * 4 / T;
	}
	else if(t < 3*T/4){
		return 2 - t * 4 / T;
	}
	else if(t < T){
		return 4 * t / T - 4;
	}
	else{
		return 0;
	}
}

//头部20号舵机运动函数
double lower_head_fun(double t, const double T)
{
	t += t_lower_offset;
	int t_int = t / T;
	double t_tmp = t - T * t_int;
	return 100.0 * saw(t_tmp, T);
}

//头部21号舵机运动函数.正弦波
double upper_head_fun(double t, const double T)
{
	t += t_upper_offset;
	int t_int = t/T;
	double t_tmp = t - T * t_int;
	double w = 2 * PI / T;
	return 50.0 * sin(w * t_tmp) + 50.0;
}

//计算开始找球时的时间偏置,有利于动作衔接
void calc_t_offset(void)
{
	t_lower_offset = (2 - head_angle[0] / 100.0) * T_lower / 4;
	double w = 2 * PI / T_upper;
	t_upper_offset = acos((head_angle[1] - 50) / 51) / w + T_upper / 4;

	switch(robot_info.lost_ball_states)
	{
	case 1:
		t_lower_offset += 2*(3*T_lower/4 - t_lower_offset);
		break;
	case 2:
		t_lower_offset += 2*(3*T_lower/4 - t_lower_offset);
		t_upper_offset += 2*(3*T_upper/4 - t_upper_offset);
		break;
	case 3:
		break;
	case 4:
		t_upper_offset += 2*(3*T_upper/4 - t_upper_offset);
		break;
	default:
		break;
	}
}

//检查找球状态跳出条件
bool search_ball_should_break(void)
{
	if(robot_info.fall_info != 0){
		robot_info.robot_state = stand_up;
		return true;
	}
	if(robot_info.ball_find){
		robot_info.robot_state = chase_ball;
		return true;
	}
	return false;
}

//找球
void lissa_search_ball(void)
{
	double t;
	calc_t_offset();
	double t0 = get_time();
	while(!search_ball_should_break()){
//	while(robot_info.ball_lost){
		t = get_time() - t0;
		if(t > T_lower){
			cout<<"search ball reset"<<endl;
			pre_reset();
			return;
		}
		move_head(lower_head_fun(t, T_lower), upper_head_fun(t, T_upper));
		delay_sec(0.005);
	}
}

//定点找球
void points_find_ball(void)
{
	double points_to_find[5] = {
			90, 45,0,-45, -90
	};
	int count = 0;
	while(!search_ball_should_break())
	{
		move_head(points_to_find[count], 90);
		count++;
		if(count == 5){
			return;
		}
		delay_sec(0.8);
	}
}

//组合找球
void co_search_ball(void)
{
	while(!search_ball_should_break())
	{
//		cout<<"co search ball "<<endl;
		lissa_search_ball();
		points_find_ball();
	}
}

//扑球动作
void action_catch_ball(void)
{

	if(robot_info.catch_ball_flag == 1){
		send_serial_flag = true;
		cout<<"右边扑球"<<endl;
		cout<<"catch ball reset"<<endl;
		pre_reset();
		sendfile("right_catch3.txt");
		cout<<"robot_info.fall_info = "<<(int)robot_info.fall_info<<endl;
		delay_sec(2);
		if(robot_info.fall_info == 1) {
			delay_sec(0.5);
			if(robot_info.fall_info == 1){
			sendfile("climb_up_forw3.txt");
			}
		}
		else{
			delay_sec(0.5);
			if(robot_info.fall_info != 1){
			sendfile("catch_to_climb3.txt");
			delay_sec(1);
			sendfile("climb_up_forw3.txt");
			}
		}
	}
	else if(robot_info.catch_ball_flag == 2){
		send_serial_flag = true;
		cout<<"左边扑球"<<endl;
		pre_reset();
		sendfile("left_catch3.txt");
		delay_sec(2);
		if(robot_info.fall_info == 1) {
			delay_sec(0.5);
			if(robot_info.fall_info == 1){
			sendfile("climb_up_forw3.txt");
			}
		}
		else{
			delay_sec(0.5);
			if(robot_info.fall_info != 1){
			sendfile("catch_to_climb3.txt");
			delay_sec(1);
			sendfile("climb_up_forw3.txt");
			}
		}
	}
	else {
		cout<<"wrong catch detection"<<endl;
	}
	delay_sec(1);
	send_serial_flag = false;
	while(robot_info.robot_state == catch_ball){
		cout<<"catch ball is done"<<endl;
	if(robot_info.fall_info != 0){
		delay_sec(0.5);
		if(robot_info.fall_info != 0){
		robot_info.robot_state = stand_up;
		break;
		}
	}
	else{
		delay_sec(0.5);
		if(robot_info.fall_info == 0){
			robot_info.robot_state = search_ball;
			break;
		}
	}
	}
	robot_info.catch_ball_flag = 0;
}

//倒地爬起动作
void action_stand_up(void)
{
	while(!catch_ball_should_break()){
		if(robot_info.fall_info == 2){
			delay_sec(0.5);
			if(robot_info.fall_info == 2){
			send_serial_flag = true;
			sendfile("back_to_forw3.txt");
			delay_sec(0.5);
			sendfile("climb_up_forw3.txt");
			send_serial_flag = false;
			}
		}
		else if(robot_info.fall_info == 1){
			delay_sec(0.5);
					if(robot_info.fall_info == 1){
			send_serial_flag = true;
			sendfile("climb_up_forw3.txt");
			delay_sec(0.5);
			send_serial_flag = false;
					}
		}
	}
}


int get_body_state(void)
{
	const int ready_kick_angle = 15;

//	cout<<"head_angle[1] = "<<head_angle[1]<<endl;
//	cout<<"head_angle[0] = "<<head_angle[0]<<endl;
	if(robot_info.ball_dis4robot<40)
	{
	if(head_angle[1] < ready_kick_angle)
	{
//		cout<<"head_angle[1] = "<<head_angle[1]<<endl;
//		cout<<"head_angle[0] = "<<head_angle[0]<<endl;
		if(fabs(head_angle[0]) < 40){
			if(head_angle[0] > 0){
				return 1;		//左脚踢
			}
			else{
				return 2;		//右脚踢
			}
		}
	}
	else{
		if(head_angle[0] > 25){
			return 3;			//左平移
		}
		else if(head_angle[0]<-25){
			return 4;			//右平移
		}
		else if(robot_info.ball_dis4robot<30){
			return 5;			//走过去
		}
	}
	}
	else return 6;


}


void body_move()
{
	if(get_body_state()==5) supportX =0.005;
	else  supportX =-0.006;

	switch(get_body_state())
				{
				case 1:
					delay_sec(0.1);
					cout<<"左脚踢球"<<endl;
					send_serial_flag = true;
					sendfile("left_kick_small.txt");
					delay_sec(1);
					send_serial_flag = false;
					update_still();
					delay_sec(1);
//					adjust_flag = true;
					break;
				case 2:
					delay_sec(0.1);
					cout<<"右脚踢球"<<endl;
//					sendfile("right_kick_small.txt");
//					adjust_flag = true;
					break;
				case 3:
					cout<<"左走"<<endl;
	//				move_left();
//					delay_sec(0.2);
					break;
				case 4:
					cout<<"右走"<<endl;
//					move_right();
//					delay_sec(0.2);
					break;
				case 5:
					//cout<<"supportX="<<supportX<<endl;
					updateOneStep(Vector3D(0.015,-0.0,-0.5*PI/180));
					cout<<"直走"<<endl;
					break;
				default:
//					cout<<"保持"<<endl;
					update_still();
					break;
				}
}

void body_adjust()
{
	Vector3D Vel_adjust = Vector3D(0,0,0);
	while(robot_info.yaw>20||robot_info.yaw<-20){
		if(robot_info.yaw>0){
			Vel_adjust.X = 0;
			Vel_adjust.Y = 0;
			Vel_adjust.Z = -5*PI/180;
		}
		else{
			Vel_adjust.X = 0;
			Vel_adjust.Y = 0;
			Vel_adjust.Z = 5*PI/180;
		}
		updateOneStep(Vel_adjust);
	}
}

//身体动作线程
void *body_pthread(void *arg)
{
	while(1)
	{
//		cout<<"game_state = "<<(int)game_state<<endl;
		if(game_state == 3){
//			cout<<"game start"<<endl;
			switch(robot_info.robot_state){
			case catch_ball:
				action_catch_ball();
				break;
			case stand_up:
				action_stand_up();
				break;
			case adjust_pos:
				body_adjust();
				break;
			default:
				update_still();
				break;
			}
		}
		else{
			update_still();
			cout<<"game interrupt"<<endl;
		}
		usleep(1);
	}
	return (void *)"body pthread return.";
}

//头部线程
void *head_pthread(void *arg)
{
	while(1)
	{
		if(game_state == 3){
			switch(robot_info.robot_state){
			case search_ball:
				co_search_ball();
				break;
			case chase_ball:
				pid_chase_ball();
				break;
			default:
				move_head(0,100);
				break;
			}
		}
		else move_head(0,80);
		usleep(1);
	}
	return (void *)"head pthread return.";
}



void *image_pthread(void *arg)
{
	while(1)
	{
		Image_Run();
		if(robot_info.ball_dis4robot>70)  	robot_info.ball_find = get_ball_pos(mat);
		else	robot_info.ball_find = get_near_ball_pos(mat) ;
	//	robot_info.ball_find = get_ball_pos(mat);
			if(!robot_info.ball_find){
				if(robot_info.ball_info.x < 160){
					if(robot_info.ball_info.y < 120){
						robot_info.lost_ball_states = 1;	//左上
					}
					else{
						robot_info.lost_ball_states = 2;	//左下
					}
				}
				else{
					if(robot_info.ball_info.y < 120){
						robot_info.lost_ball_states = 3;	//右上
					}
					else{
						robot_info.lost_ball_states = 4;	//右下
					}
				}
			}

			Image_Show();
			char c = cvWaitKey(1);
					if(c == 27 )
					{
						Image_Clear();
						exit(0);
					}

					usleep(1);
	}
	return (void *)"image pthread return!";
}


void *network_pthread(void *arg)
{
	while(1)
	{
							recv_game_control_data(get_ref_buf );
							 get_info(get_ref_buf );
	//					info_output( );
						usleep(1);
	}
	return (void *)"network pthread return!";
}



void *serial_pthread(void *arg)
{
	while(1)
	{
		if(send_serial_flag == false)
		{
			serial_head();
			delay_sec(0.0055);
			serial_legs();
			delay_sec(0.0035);
			serial_hands();
			delay_sec(0.0025);
		}
	//	image_update();
	//	serial_all();
	//	delay_sec(0.0055);
			usleep(1);
		}
	return (void *)"serial pthread return.";
}



