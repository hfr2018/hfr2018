/*
 * global.h
 *
 *  Created on: 2014年9月14日
 *      Author: xuf
 */

#ifndef GLOBAL_H_
#define GLOBAL_H_

//#define GONG_KONG
//head file
//c++
#include <iostream>
#include <cmath>
#include <string>
#include <iomanip>
#include <fstream>
#include <vector>
using namespace std;
#include<math.h>
//c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

//unix
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <termios.h>
#include <errno.h>
#include <sys/time.h>
#include <signal.h>
//线程
#include <pthread.h>
//network
#include <sys/socket.h>
#include"tcp.h"
#include <netinet/in.h>
#include <arpa/inet.h>
//信号量
#include <semaphore.h>

//opencv
#include "highgui.h"
#include "cv.h"
#include "cxcore.h"

//裁判盒
#include "ref_box.h"

#define byte unsigned char

typedef struct{
	double r;
	int x;
	int y;
}Ball_info;


typedef struct{
	int ep;
	int ei;
	int ed;
	double kp;
	double ki;
	double kd;
	double t;
	int dz;
}PID;

enum Robot_state{						//机器人状态
	search_ball,
	chase_ball,
	catch_ball,
	adjust_pos,
	stand_up,
};


//自定义
//在线步态
#include "Point.h"
using namespace Robot;
#include "Matrix.h"
#include "Vector.h"
#include "OPKinematics.h"
#include "basicwalk.h"
#include "Transform.h"

#include "util.h"
#include "image.h"
#include "pthread.h"
#include "pid_debug.h"
#include "predict.h"



class Robot_info{
public:
	Robot_state robot_state;
	Ball_info ball_info;		//球在视野中的信息
	bool ball_find;				//是否丢球
	double yaw;					//机器人航向角, yaw<0时航向角无效(摔倒)
	double yaw_start;//初始航向角
	byte fall_info;				//机器人是否摔倒，0:没有摔倒，1:向前摔倒，2:向后摔倒, 0xaa:读取失败
	int  lost_ball_states;		//丢球状态， 1:左上， 2:左下， 3:右上， 4:右下
	int pre_points_count;
	int catch_ball_flag;		//0:不扑球，1:左扑球， 2:右扑球, 3:走过去踢球,
	bool start_take_pos_flag;	//开始采点标志
	double ball_dis4robot;		//球到机器人的距离

	Robot_info(){
		ball_info.x = 160;
		ball_info.y = 120;
		robot_state = search_ball;
		ball_find = false;
		yaw = 0;
		yaw_start=0;
		fall_info = 0;
		lost_ball_states = 0;
		pre_points_count = 0;
		catch_ball_flag = 0;
		start_take_pos_flag = false;
		ball_dis4robot = 100;
	}
	void calc_ball_info()
		{
		double r =	ball_info.r;
		//	ball_dis4robot  = fabs(-0.00349*r*r*r +0.417*r*r - 18.22*r +320.5);
			ball_dis4robot = fabs(0.000604*r*r*r+0.01113*r*r-6.736*r+252);
		}
};

//全局变量声明
extern int fd;
extern int fd_arm;
extern unsigned char buf_angle[11];
extern Robot_info robot_info;
//摄像头角度
extern double head_angle[2];
extern PID pid_lower;
extern PID pid_upper;
extern int int_low_kp;
extern int int_low_ki;
extern int int_low_kd;
extern int int_up_kp;
extern int int_up_ki;
extern int int_up_kd;


extern Ball_pos pre_points[5];
extern Pre_par pre_par;
extern Pre_res pre_res;

extern double T_lower;
extern double T_upper;
extern double t_lower_offset;
extern double t_upper_offset;

extern int yz_ball[6];

//图像
extern unsigned char H,S,V,R,G,B;
extern unsigned char HSV[64][64][64],RGB[64][64][64];
extern int threshold_houghline ;
extern int param1 ;
extern int param2 ;
extern int white_points_low_2 ;
extern int white_points_up_2 ;
extern int green_points_low_2 ;
extern int green_points_up_2;
extern int green_circle_low_2;
extern int green_circle_up_2;
extern int max_count_best_2 ;
extern int white_points_low_1;
extern int white_points_up_1;
extern int green_points_low_1;
extern int green_points_up_1;
extern CvCapture* capture;
extern IplImage *show_Image,*Image,* pImage,*ball_Image,*ball_Image_gray,*field_Image,*field_Image_gray;
extern CvSeq *cont;
extern CvMat* edges;										//第一种方法将轮廓画入这张图,用于第二种方法处理
extern CvMat temp;
extern CvMat* mat;									//用于拷贝的矩阵,传入函数icvHoughCirclesGradient
extern Ball_info ball_info;
extern CvMemStorage *stor;


extern bool send_serial_flag;

//裁判盒


typedef struct{
	char penalty;
	char secs_to_unpen;
}PlayerInfo;



//teamInfo
typedef struct{
	char number;
	char color;
	char score;
	char penalty_shot;
	short int single_shots;
	char SPL_coach_message[40];
	PlayerInfo players_info[5];
}TeamInfo;

extern int client_sock;
extern int sock;
extern struct sockaddr_in addr_to;
extern struct sockaddr_in addr_from;
extern char return_data_buffer[8];

extern char  get_ref_buf[1023];



//massage
extern char num_players;
extern char game_state;
extern char frist_half;
extern char kickoff_team;
extern char sec_game_state;
extern char dropin_team;
extern short int dropin_time;
extern short int secs_remaining;
extern short int secondary_time;
extern TeamInfo team1;
extern TeamInfo team2;

#endif /* GLOBAL_H_ */
