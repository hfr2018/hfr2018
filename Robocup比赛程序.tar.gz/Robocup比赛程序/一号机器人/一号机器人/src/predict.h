/*
 * predict.h
 *
 *  Created on: 2014年10月5日
 *      Author: xuf
 */

#ifndef PREDICT_H_
#define PREDICT_H_

#include "global.h"

typedef struct{
	double x;
	double y;
}Ball_pos;

//所有点的结构体
typedef struct {
	int num;    //取的点的个数 n<-6
	Ball_pos point[5]; //获取的点的信息的数组
	double t[4];
	double interval;  //时间间隔
}Pre_par;

//预测结果的结构体
typedef struct {
	double arriveTime;
	double y;
}Pre_res;

void pre_reset(void);
double calc_dis(void);
double calc_angle(void);
Ball_pos get_point(void);
void update_points(double interval);
int Judge_result(void);
double get_pre_res(void);
int get_body_state(void);


#endif /* PREDICT_H_ */
