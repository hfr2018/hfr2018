/*
 * predict.cpp
 *
 *  Created on: 2014年10月5日
 *      Author: xuf
 */

#include "global.h"

//predict parament reset
void pre_reset(void)
{
	Ball_pos buf_ball;
	buf_ball.x = 0;
	buf_ball.y = 0;
	byte i;
	pre_par.interval = 0.10;
	pre_par.num = 0;
	for(i = 0;i<=3;i++){
		pre_par.t[i] = 0;
	}
	for(i = 0;i<=4;i++){
		pre_par.point[i] = buf_ball;
	}

//	pre_res.arriveTime = 10000;
//	pre_res.y = 0;
}
/*

//计算球离机器人的距离
double calc_dis(void)
{
	double k = 29.029;
	if(head_angle[1] < 15){
		k = 31.508;
	}
	return 1/robot_info.ball_info.r * k;
}

//计算头偏离x轴的角度，单位：弧度
double calc_angle(void)
{
	const double k = 0.019;
	const double b = 0.050;
	return head_angle[0] * k + b;
}

//return the newlest point
Ball_pos get_point(void)
{
	Ball_pos resault;
	double dis = calc_dis();
	double angle  = calc_angle();
	cout<<"r = "<<robot_info.ball_info.r<<"  ---  dis = "<<dis<<"  ---  angle = "<<angle<<endl;
	resault.x = dis * cos(angle);
	resault.y = dis * sin(angle);
	return resault;
}

void update_points(void)
{
	for(int i=5; i>0; i--){
		pre_par.point[i] = pre_par.point[i-1];
	}
	pre_par.point[0] = get_point();

	cout<<endl;
	cout<<"points:"<<endl;
	for(int i=0; i<pre_par.num; i++){
		cout<<pre_par.point[i].x<<"  "<<pre_par.point[i].y<<endl;
	}
	cout<<endl;
}

//分析预测结果，判断是否扑球
int Judge_result(void)
{
	cout<<"time = "<<pre_res.arriveTime<<"................."<<endl;
	if(pre_res.arriveTime > 1.5){
		if(head_angle[0] > 40){
			return 4;
		}
		if(head_angle[0] < -40){
			return 5;
		}
		return 0;
	}
	if(fabs(pre_res.y) > 2){
		return 0;
	}
	if(pre_res.y > 0){
		return 1;
	}
	return 2;
}

void get_pre_res(void)
{
	double vx, vy, t, y_tmp;
	if(pre_par.num == 6){
		vx = ((pre_par.point[5].x + pre_par.point[4].x + pre_par.point[3].x) - (pre_par.point[2].x + pre_par.point[1].x + pre_par.point[0].x)) / (9 * pre_par.interval);
		t = pre_par.point[0].x / vx;
		vy = ((pre_par.point[5].y + pre_par.point[4].y + pre_par.point[3].y) - (pre_par.point[2].y + pre_par.point[1].y + pre_par.point[0].y)) / (9 * pre_par.interval);
		y_tmp = pre_par.point[0].y + vy * t;
	}
	else{
		vx = ((pre_par.point[3].x + pre_par.point[2].x) - (pre_par.point[1].x + pre_par.point[0].x)) / (4 * pre_par.interval);
		t = pre_par.point[0].x / vx;
		vy = ((pre_par.point[0].y + pre_par.point[1].y) - (pre_par.point[2].y + pre_par.point[3].y)) / (4 * pre_par.interval);
		y_tmp = pre_par.point[0].y + vy * t;
	}
	pre_res.arriveTime = t;
	pre_res.y = y_tmp;
}

*/


//计算头偏离x轴的角度，单位：弧度
double calc_angle(void)
{
	const double k = 0.01084;   //k = ((300*300/1024*PI/180)-PI/3 - PI/2)/100
	const double b = PI/2;
	return head_angle[0] * k + b;
}

Ball_pos get_point(void)
{
	Ball_pos result;
	robot_info.calc_ball_info();
	double dis = robot_info.ball_dis4robot;
	double angle  = calc_angle();
	cout<<"r = "<<robot_info.ball_info.r<<"  ---  dis = "<<dis<<"  ---  angle = "<<angle<<endl;
	result.x = dis * cos(angle);
	result.y = dis * sin(angle);
	return result;
}


void update_points(double interval)
{

	Ball_pos buf_ball = get_point();
	if(pre_par.point[0].y != 0){
		double v = fabs((pre_par.point[0].y - buf_ball.y)/interval);				//为消除误识别的影响
		cout<<"v                                     tmp = "<<v<<endl;
			if(v < 250){
				cout<<"update"<<endl;
				pre_par.point[4] = pre_par.point[3];
				pre_par.point[3] = pre_par.point[2];
				pre_par.point[2] = pre_par.point[1];
				pre_par.point[1] = pre_par.point[0];
				pre_par.point[0] = buf_ball;
				pre_par.t[3] = pre_par.t[2];
				cout<<"pre_par.t[3] 1 ="<<pre_par.t[3]<<endl;
				pre_par.t[2] = pre_par.t[1];
				cout<<"pre_par.t[2] 1 ="<<pre_par.t[2]<<endl;
				pre_par.t[1] = pre_par.t[0];
				cout<<"pre_par.t[1] 1 ="<<pre_par.t[1]<<endl;
				pre_par.t[0] = interval;
				cout<<"pre_par.t[0] 1 ="<<pre_par.t[0]<<endl;
				cout<<"pre_par.point[4].y = "<<pre_par.point[4].y<<endl;
				cout<<"pre_par.point[3].y = "<<pre_par.point[3].y<<endl;
				cout<<"pre_par.point[2].y = "<<pre_par.point[2].y<<endl;
				cout<<"pre_par.point[1].y = "<<pre_par.point[1].y<<endl;
				if(pre_par.num<5)
				{
					pre_par.num++;
				}
			}
			else cout<<"wrong detection of ball distance"<<endl;
	}
	else{
		cout<<"update"<<endl;
		pre_par.point[0] = buf_ball;
//		cout<<"pre_par.t[0] 1 ="<<pre_par.t[0]<<endl;
		pre_par.t[3] = pre_par.t[2];
		pre_par.t[2] = pre_par.t[1];
		pre_par.t[1] = pre_par.t[0];
		pre_par.t[0] = interval;
		if(pre_par.num<5)
		{
			pre_par.num++;
		}
	}



//	cout<<"prepar num="<<pre_par.num<<endl;
}





double get_pre_res(void)
{
	double vy=0 ;
	if(pre_par.num == 5)
	{
		cout<<"point 2 = "<<pre_par.point[2].y<<"     "<<"point 1 = "<<pre_par.point[1].y<<"     "<<"point 0 = "<<pre_par.point[0].y<<endl;
		cout<<(pre_par.point[4].y-pre_par.point[3].y) /pre_par.t[3]<<endl;
		cout<<(pre_par.point[3].y-pre_par.point[2].y) /pre_par.t[2]<<endl;
		cout<<(pre_par.point[2].y-pre_par.point[1].y) /pre_par.t[1]<<endl;
		cout<< (pre_par.point[1].y-pre_par.point[0].y) /pre_par.t[0]<<endl;
/*		cout<<"pre_par.t[3]="<<pre_par.t[3]<<endl;
		cout<<"pre_par.t[2]="<<pre_par.t[2]<<endl;
		cout<<"pre_par.t[1]="<<pre_par.t[1]<<endl;
		cout<<"pre_par.t[0]="<<pre_par.t[0]<<endl;*/
		vy = ( (pre_par.point[4].y-pre_par.point[3].y) /pre_par.t[3]+ (pre_par.point[3].y-pre_par.point[2].y) /pre_par.t[2]+(pre_par.point[2].y-pre_par.point[1].y) /pre_par.t[1]+(pre_par.point[1].y-pre_par.point[0].y) /pre_par.t[0])/4;
	}
	return vy;
}
