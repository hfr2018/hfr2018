/*
 * pid_debug.h
 *
 *  Created on: 2014年10月4日
 *      Author: xuf
 */

#ifndef PID_DEBUG_H_
#define PID_DEBUG_H_


double pid_calc_lower(PID *pid);
double pid_calc_upper(PID *pid);
void pid_reset(void);

#endif /* PID_DEBUG_H_ */
