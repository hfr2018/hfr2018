/*
 * image.h
 *
 *  Created on: 2014年9月15日
 *      Author: xuf
 */

#ifndef IMAGE_H_
#define IMAGE_H_

#include "global.h"

#define FLAG_HSV  0
#define FLAG_YUV  1

void *image_pthread(void *arg);

int Image_Init();
void Image_Run();
void Image_Show();
void Image_Clear();
void Color_Table_field_ball(IplImage *src );
void Color_Table_goal(IplImage *src );
int Read_ColorTable();
bool get_ball_pos(CvMat *src);
bool get_near_ball_pos(CvMat *src);
bool get_ball_pos_1(CvMat *src);
void print(IplImage* img, int x, int y, const char* text);
bool get_ball_pos_2( CvMat* img, float dp,
                         int min_radius, int max_radius,
                          float acc_threshold,float max_count_best_threshold);
bool image_update();
#endif /* IMAGE_H_ */
