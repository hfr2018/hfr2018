/*
 * pid_debug.cpp
 *
 *  Created on: 2014年10月4日
 *      Author: xuf
 */

#include "global.h"

double pid_calc_lower(PID *pid)
{
	const int err_yz = pid->dz;	//误差阈值，误差小于该值不用调节
	const double out_limit = 15.0;
	pid->ep = ( robot_info.ball_info.x-160);					//因为时根据原图像调节的pid参数,现在图像缩小了一倍,所以将误差乘以2
	if(abs(pid->ep) < err_yz){
//		cout<<"pid_low_right"<<endl;
		return 0;
	}
	pid->kp = (double)int_low_kp/1000;
	pid->ki = (double)(int_low_ki-100)/1000;
	pid->kd = (double)int_low_kd/1000;
//	cout<<"ep_low = "<<pid->ep<<endl;
	double u0 = pid->kp * pid->ep + pid->ki * pid->ei + pid->kd * pid->ed;
	pid->ed = pid->ei;
	pid->ei = pid->ep;
	u0 = min(max(-out_limit, u0), out_limit);
	return u0;
}

double pid_calc_upper(PID *pid)
{
	const int err_yz = pid->dz;	//误差阈值，误差小于该值不用调节
	const double out_limit = 5.0;
	pid->ep = (robot_info.ball_info.y - 120);
	if(abs(pid->ep) < err_yz){
//		cout<<"pid_up_right"<<endl;
		return 0;
	}
	pid->kp = (double)int_up_kp/1000;
	pid->ki = (double)(int_up_ki-100)/1000;
	pid->kd = (double)int_up_kd/1000;
//	cout<<"ep_up = "<<pid->ep<<endl;
	double u0 = pid->kp * pid->ep + pid->ki * pid->ei + pid->kd * pid->ed;
	pid->ed = pid->ei;
	pid->ei = pid->ep;
	u0 = min(max(-out_limit, u0), out_limit);
	return u0;
}

void pid_reset(void)
{
	pid_lower.ep = 0;
	pid_lower.ei = 0;
	pid_lower.ed = 0;

	pid_upper.ep = 0;
	pid_upper.ei = 0;
	pid_upper.ed = 0;
}
