/*
 * pthread.h
 *
 *  Created on: 2014年10月2日
 *      Author: xuf
 */

#ifndef PTHREAD_H_
#define PTHREAD_H_

void serial_all(void);
void *serial_pthread(void *arg);
void pid_chase_ball(void);

double saw(double t, const double T);
double lower_head_fun(double t, const double T);
double upper_head_fun(double t, const double T);
void calc_t_offset(void);
void lissa_search_ball(void);
void points_find_ball(void);
void co_search_ball(void);
void *head_pthread(void *arg);
void *body_pthread(void *arg);
void *network_pthread(void *arg);



#endif /* PTHREAD_H_ */
