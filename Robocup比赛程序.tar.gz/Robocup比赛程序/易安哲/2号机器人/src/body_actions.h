/*
 * actions.h
 *
 *  Created on: 2014年9月17日
 *      Author: xuf
 */

#ifndef ACTIONS_H_
#define ACTIONS_H_
#include"global.h"


void body_search(void);
void body_chase(void);
void body_kick(void);
void body_round_yaw(void);
void body_search_goal(void);
void body_adjust_ball(void);
void body_round_goal(void);
void body_approach_ball(void);
void body_climb_up(void);




#endif /* ACTIONS_H_ */
