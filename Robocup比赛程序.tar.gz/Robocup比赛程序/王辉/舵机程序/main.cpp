#include"golbal.h"
#include"util.h"
#include"function.h"


int main()
{
    int fdc=openport();
    if(fdc!=0)
    {
       cout<<"init port error"<<endl;
       return -1;
    }
    while(1)
    {

#ifdef CHANGEANGLE
    //initnum1();
    //writeport(data,8);
    getangle();
    initnum();
    writeport(angle ,11);
#endif // CHANGEANGLE

#ifdef SETID
    getid();
    initnum();
    writeport(data,8);
#endif // SETID

#ifdef SETBPS
    getbps();
    initnum();
    writeport(data,8);
#endif // SETBPS

#ifdef GETM
    chufa();

    if(pthread_create(&send_t,NULL,send_return_command,NULL)!=0)
    cout<<"send pthread fail"<<endl;
    cout<<"send pthread succeed"<<endl;

    if(pthread_create(&get_t,NULL,get_return,NULL)!=0)
    cout<<"get pthread fail"<<endl;
    cout<<"get pthread succeed"<<endl;

    void *pthread_result;

    pthread_join(send_t, &pthread_result);
    pthread_join(get_t, &pthread_result);
#endif // GETM

    }
    closeport();
    return 0;
}
