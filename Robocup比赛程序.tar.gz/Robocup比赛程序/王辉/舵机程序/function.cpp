#include"golbal.h"
#include"util.h"

int fd;  //串口
int setangle;
char angle[11];
int id;
int bps;
char data[8];
char getdata[8];
int matair[8];

pthread_t send_t;
pthread_t get_t;
char getcorrectbps();

void getangle()
{
   cout<<"请输入角度"<<endl;
   cin>>setangle;
}

void getid()
{
   cout<<"请输入id"<<endl;
   cin>>id;
}

void getbps()
{
   cout<<"请输入bps"<<endl;
   cin>>bps;
}

void initnum()
{
#ifdef CHANGEANGLE
   angle[0]=0xff;
   angle[1]=0xff;
   angle[2]=0xfe;
   angle[3]=0x07;
   angle[4]=0x03;
   angle[5]=0x1e;
   angle[6]=setangle&0xff;
   angle[7]=(setangle>>8)&0xff;
   angle[8]=0xff;
   angle[9]=0x01;
   angle[10]=(~(angle[2]+angle[3]+angle[4]+angle[5]+angle[6]+angle[7]+angle[8]+angle[9]))&0xff;
#endif // CHANGEANGLE

#ifdef SETID
   data[0]=0xff;
   data[1]=0xff;
   data[2]=0xfe;
   data[3]=0x04;
   data[4]=0x03;
   data[5]=0x03;
   data[6]=id&0xff;
   data[7]=(~(data[2]+data[3]+data[4]+data[5]+data[6]))&0xff;
#endif

#ifdef SETBPS
   data[0]=0xff;
   data[1]=0xff;
   data[2]=0xfe;
   data[3]=0x04;
   data[4]=0x03;
   data[5]=0x04;
   data[6]=getcorrectbps();
   data[7]=(~(data[2]+data[3]+data[4]+data[5]+data[6]))&0xff;
#endif // SETBPS

#ifdef GETM
   data[0]=0xff;
   data[1]=0xff;
   data[2]=0x05;
   data[3]=0x04;
   data[4]=0x02;
   data[5]=0x28;
   data[6]=0x02;
   data[7]=(~(data[2]+data[3]+data[4]+data[5]+data[6]))&0xff;
#endif // GETM

}
void initnum1()
{
   data[0]=0xff;
   data[1]=0xff;
   data[2]=0xfe;
   data[3]=0x04;
   data[4]=0x03;
   data[5]=0x18;
   data[6]=0x01;
   data[7]=(~(data[2]+data[3]+data[4]+data[5]+data[6]))&0xff;
}
char getcorrectbps()
{
   char m;
   switch(bps)
   {
      case 1000000:
         m=0x01;break;
      case 500000:
         m=0x03;break;
      case 400000:
         m=0x04;break;
      case 250000:
         m=0x07;break;
      case 200000:
         m=0x09;break;
      case 115200:
         m=0x10;break;
      case 57600:
         m=0x22;break;
      case 19200:
         m=0x67;break;
      case 9600:
         m=0xcf;break;
      default:
       {
          cout<<"bps input error,set bps 115200"<<endl;
          m=0x10;
       }
   }
   return m;
}

void chufa()
{
     int m;
     do
     {
     cout<<"if continue?(if, input 1)"<<endl;
     cin>>m;
     }while(m!=1);
}

void *send_return_command(void *arg)
{
    initnum();
    while(1)
    {
    //usleep(20000);
    writeport(data,8);
    usleep(5000);
    }
    return (void*)"send finish";
}
void analydata()
{
    for(int i=0;i<8;i++)
    {
        matair[i]=((int)*(getdata+i))&0xff;
    }
}
void *get_return(void *arg)
{
    while(1)
    {
    readport(getdata,8);
    analydata();
    if(matair[0]==255&&matair[1]==255)
       cout<<matair[0]<<"\t"<<matair[1]<<"\t"<<matair[2]<<"\t"<<matair[3]<<"\t"<<matair[4]<<"\t"<<matair[5]<<"\t"<<matair[6]<<"\t"<<matair[7]<<endl;
    usleep(100000);
    }
    return (void*)"get finish";
}

