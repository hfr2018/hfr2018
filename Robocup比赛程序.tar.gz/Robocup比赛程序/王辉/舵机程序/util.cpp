#include<fcntl.h>
#include <unistd.h>
#include<termios.h>
#include"golbal.h"
#include"util.h"
#include"function.h"

int openport()
{
    int a;
    a=portinit("/dev/ttyUSB0");
    if(a==-1)
       {
          a=portinit("/dev/ttyUSB1");
          if(a==-1)
          {
             a=portinit("/dev/ttyUSB2");
             if(a==-1)
              {
                 a=portinit("/dev/ttyUSB3");
                 if(a==-1) return -1;
                 else return 0;
              }
          return 0;
          }
       return 0;
       }
    return 0;
}
int portinit(const char* dev)
{
   fd=open(dev,O_RDWR | O_NOCTTY | O_NONBLOCK);
   if(fd!=-1)
   {
      struct termios inite;
      if (tcgetattr(fd, &inite) != 0)
            cout<<"get port error"<<endl;
      inite.c_cflag=B115200|CS8|CLOCAL|CREAD;
      inite.c_iflag=IGNPAR;
      inite.c_oflag=0;
      inite.c_lflag=0;
      inite.c_cc[VTIME]=0;
      inite.c_cc[VMIN]=0;
      if(tcsetattr(fd,TCSANOW,&inite)!=0)
            cout<<"set port error"<<endl;
     return 1;
   }
   else return -1;
}

void closeport()
{
      close(fd);
}

void writeport(char *sendnum,int num)
{
     write(fd,(void*)sendnum,num);
}

void readport(char *getnum,int num)
{
     read(fd,(void*)getnum,num);
}
