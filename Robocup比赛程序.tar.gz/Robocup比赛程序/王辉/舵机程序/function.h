void getangle();
void getid();
void getbps();
void initnum();
void initnum1();
void *send_return_command(void *arg);
void *get_return(void *arg);
void chufa();
