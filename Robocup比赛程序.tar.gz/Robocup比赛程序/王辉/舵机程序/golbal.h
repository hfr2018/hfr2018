#include<iostream>
using namespace std;
#include <pthread.h>
#include <unistd.h>
#define CHANGEANGLE  //设置角度
//#define SETBPS       //设置波特率
//#define SETID        //设置ID
//#define GETM       //获得扭矩


extern int fd;
extern int setangle;
extern char angle[11];
extern int id;
extern int bps;
extern char data[8];

extern pthread_t send_t;
extern pthread_t get_t;
