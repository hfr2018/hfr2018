int openport();
int portinit(const char* dev);
void closeport();
void writeport(char *sendnum,int num);
void readport(char *getnum,int num);
