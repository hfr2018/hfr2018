#include<fcntl.h>
#include <unistd.h>
#include<termios.h>
#include<iostream>
using namespace std;

int fd;
int m;
unsigned char setnum[5];
char getdate1[42];
double angle[3];
int shuju[20];

void initnum()
{
  setnum[0]=0xff;
  setnum[1]=0xaa;
  setnum[2]=0x02;
  setnum[3]=0x08;
  setnum[4]=0x00;
}

void sendfile()
{
   write(fd,setnum,5);
}

int portinit(const char* dev)
{
   fd=open(dev,O_RDWR | O_NOCTTY | O_NONBLOCK);
   if(fd!=-1)
   {
      struct termios inite;
      if (tcgetattr(fd, &inite) != 0)
            cout<<"get"<<endl;
      inite.c_cflag=B115200|CLOCAL|CREAD|CS8;
      inite.c_iflag=IGNPAR;
      inite.c_oflag=0;
      inite.c_lflag=0;
      inite.c_cc[VTIME]=0;
      inite.c_cc[VMIN]=0;
      //cout<<"a"<<endl;
      if(tcsetattr(fd,TCSANOW,&inite)!=0)
            cout<<"set"<<endl;
     return 1;
   }
   else return 0;
}
void getangle(void* num)
{

for(int i=0;i<11;i++)
{
    shuju[i]=(int)*(getdate1+i);
}

   angle[0]=(double)(shuju[2]|shuju[3]<<8)/32768*180.0;
   angle[1]=(double)(shuju[4]|shuju[5]<<8)/32768*180.0;
   angle[2]=(double)(shuju[6]|shuju[7]<<8)/32768*180.0;
}

void getreturnport()
{
    while(1)
    {
    m=read(fd,(void*)getdate1,20);
    if(*getdate1==0x55&&(*(getdate1+1))==0x53)
    {
    //getdate1[0]=getdate1[1]+1;
    getangle(getdate1);
    break;
    }
    }

}

void closeport()
{
     close(fd);
}

int main()
{
    int fdr=portinit("/dev/ttyUSB1");
//    initnum();
//    sendfile();
    while(1)
    {
    getreturnport();
    //cout<<angle[0]<<"   "<<angle[1]<<"  "<<angle[2]<<endl;
    //cout << *getdate1[0]<<"  "<< *(int*)getdate1[1]<<"  "<< *(int*)getdate1[2]<<"  "<< *(int*)getdate1[3]<<"  "<< *(int*)getdate1[4]<<"  "<< *(int*)getdate1[5]<<"  "<< *(int*)getdate1[6]<<"  "<< *(int*)getdate1[7]<<"  "<<endl;//[1]<<getdate[2]<<getdate[3]<<getdate[4]<<getdate[5]<<getdate[6]<<getdate[7]<<getdate[8]<<getdate[9]<<getdate[10]<<getdate[11]<< endl;
    //cout<<*getdate1<<"  "<<*(getdate1+2)<<"  "<<*(getdate1+3)<<"  "<<*(getdate1+4)<<"  "<<*(getdate1+5)<<"  "<<*(getdate1+6)<<"  "<<*(getdate1+7)<<"  "<<*(getdate1+8)<<"  "<<*(getdate1+9)<<"  "<<*(getdate1+10)<<endl;
    /*for(int m=0;m<20;m++)
    {
      cout<<shuju[m]<<" ";
    }
    cout<<endl;*/
    cout<<shuju[0]<<'\t'<<shuju[1]<<'\t'<<angle[0]<<'\t'<<angle[1]<<'\t'<<angle[2]<<endl;
    usleep(100000);
   }
    closeport();
    return 0;
}
